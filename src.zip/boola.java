import java.util.*;
public class boola {
	public static void main(String [] args)
	{
Scanner s=new Scanner(System.in);
eva e=new eva();
String str=s.nextLine();
boolean b=e.EvaluateExpression(str);
String r="";
if(b==true)
	r="true";
else
	r="false";
System.out.println("the evaluated expression is "+r);	
}
}

