
public interface booleanexp {
	public boolean EvaluateExpression(String s);
}
