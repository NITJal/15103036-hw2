
public class allsubstrings {
	public static void main(String [] args) {
		String s = "AACE";
		int len=s.length();
for(int i =0;i<s.length();i++)
{
	for(int j =1;j<=len-i;j++)
	{
		System.out.println(s.substring(i, i+j));
	}
}
	
}
}