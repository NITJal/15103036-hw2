
public class rotation {
	public static void main(String [] args) {
		String s="AACE";
		String s1=s.concat(s);
		for(int i=0;i<s.length();i++)
		{
			System.out.println(s1.substring(i,i+4));
		}
		
		
		
	}

}
